-- ============================================================
-- Sportbase andmebaas - INSERT laused (testandmed)
-- Autor: Marcus Krutto
-- ============================================================

USE sportbase;

-- ------------------------------------------------------------
-- Ruumid (2 kirjet)
-- ------------------------------------------------------------
INSERT INTO ruumid (nimi, mahtuvus_min, mahtuvus_max, varustus, markus) VALUES
('Spordihall', 20, 30, 'Trenniks vajalik varustus',  NULL),
('Jõusaal',   5,  10, 'Jõusaalis olev varustus',    NULL);

-- ------------------------------------------------------------
-- Kasutajad (10 kirjet)
-- Paroolid on siin lihtsalt näidis-hashid (bcrypt kujul)
-- ------------------------------------------------------------
INSERT INTO kasutajad (eesnimi, perenimi, email, parool_hash, roll) VALUES
('Kaspar',   'Kariste',  'kaspar.kariste@kool.ee',   '$2b$12$dummyhash1xxxxxxxxxxxxxxxxx', 'Treener'),
('Mari',     'Mägi',     'mari.magi@kool.ee',        '$2b$12$dummyhash2xxxxxxxxxxxxxxxxx', 'Administraator'),
('Jaan',     'Tamm',     'jaan.tamm@kool.ee',        '$2b$12$dummyhash3xxxxxxxxxxxxxxxxx', 'Õpetaja'),
('Liisa',    'Kask',     'liisa.kask@kool.ee',       '$2b$12$dummyhash4xxxxxxxxxxxxxxxxx', 'Õpetaja'),
('Peeter',   'Pärn',     'peeter.parn@opilane.ee',   '$2b$12$dummyhash5xxxxxxxxxxxxxxxxx', 'Õpilane'),
('Anna',     'Lepp',     'anna.lepp@opilane.ee',     '$2b$12$dummyhash6xxxxxxxxxxxxxxxxx', 'Õpilane'),
('Markus',   'Saar',     'markus.saar@opilane.ee',   '$2b$12$dummyhash7xxxxxxxxxxxxxxxxx', 'Õpilane'),
('Kätlin',   'Vaher',    'katlin.vaher@opilane.ee',  '$2b$12$dummyhash8xxxxxxxxxxxxxxxxx', 'Õpilane'),
('Risto',    'Kuusk',    'risto.kuusk@opilane.ee',   '$2b$12$dummyhash9xxxxxxxxxxxxxxxxx', 'Õpilane'),
('Merle',    'Haab',     'merle.haab@opilane.ee',    '$2b$12$dummyhash10xxxxxxxxxxxxxxxx', 'Õpilane');

-- ------------------------------------------------------------
-- Spordiala (6 kirjet) — treener_id=1 on Kaspar Kariste
-- ------------------------------------------------------------
INSERT INTO spordiala (nimi, kirjeldus, ruum_id, trenni_aeg_algus, trenni_aeg_lopp,
                        mis_paevad, kordade_arv_naadalas, max_osalejad, treener_id) VALUES
('Võrkpall',          NULL,                        1, '16:00', '17:30', 'E-N', 4, 15, 1),
('Korvpall',          NULL,                        1, '16:00', '17:30', 'E-N', 4, 15, 1),
('Jalgpall',          NULL,                        1, '16:00', '17:30', 'E-N', 4, 20, 1),
('Sulgpall',          NULL,                        1, '16:00', '17:30', 'E-N', 4, 15, 1),
('Jõusaal',           'Kõik võivad kasutada',      2, '16:00', '21:00', 'E-N', 4,  5, NULL),
('Tüdrukute jõusaal', 'Ainult tüdrukud kasutavad', 2, '16:00', '17:00', 'E-N', 4,  5, NULL);

-- ------------------------------------------------------------
-- Broneeringud (12 kirjet)
-- kasutaja_id 5–10 on õpilased, 3–4 on õpetajad
-- ------------------------------------------------------------
INSERT INTO broneeringud (kasutaja_id, spordiala_id, staatus) VALUES
(5,  1, 'Aktiivne'),    -- Peeter -> Võrkpall
(5,  5, 'Aktiivne'),    -- Peeter -> Jõusaal
(6,  2, 'Aktiivne'),    -- Anna -> Korvpall
(6,  6, 'Aktiivne'),    -- Anna -> Tüdrukute jõusaal
(7,  3, 'Aktiivne'),    -- Markus -> Jalgpall
(7,  1, 'Tühistatud'),  -- Markus -> Võrkpall (tühistatud)
(8,  6, 'Aktiivne'),    -- Kätlin -> Tüdrukute jõusaal
(8,  4, 'Aktiivne'),    -- Kätlin -> Sulgpall
(9,  3, 'Aktiivne'),    -- Risto -> Jalgpall
(10, 2, 'Aktiivne'),    -- Merle -> Korvpall
(3,  1, 'Aktiivne'),    -- Õpetaja Jaan -> Võrkpall
(4,  5, 'Lõppenud');    -- Õpetaja Liisa -> Jõusaal (lõppenud)

-- ------------------------------------------------------------
-- Osalejad (10 kirjet)
-- ------------------------------------------------------------
INSERT INTO osalejad (kasutaja_id, spordiala_id, liitumise_kuupäev) VALUES
(5,  1, '2025-09-02'),  -- Peeter -> Võrkpall
(6,  2, '2025-09-02'),  -- Anna -> Korvpall
(7,  3, '2025-09-02'),  -- Markus -> Jalgpall
(8,  4, '2025-09-02'),  -- Kätlin -> Sulgpall
(9,  3, '2025-09-03'),  -- Risto -> Jalgpall
(10, 2, '2025-09-03'),  -- Merle -> Korvpall
(5,  5, '2025-09-04'),  -- Peeter -> Jõusaal
(6,  6, '2025-09-04'),  -- Anna -> Tüdrukute jõusaal
(8,  6, '2025-09-05'),  -- Kätlin -> Tüdrukute jõusaal
(3,  1, '2025-09-02');  -- Õpetaja Jaan -> Võrkpall
