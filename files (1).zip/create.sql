-- ============================================================
-- Sportbase andmebaas - CREATE TABLE laused
-- Autor: Marcus Krutto
-- ERD põhjal: Päev 1, Task 2
-- ============================================================

CREATE DATABASE IF NOT EXISTS sportbase
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sportbase;

-- ------------------------------------------------------------
-- Tabel: ruumid
-- Kirjeldab spordihoone ruume (spordihall, jõusaal jne)
-- ------------------------------------------------------------
CREATE TABLE ruumid (
    ruum_id     INT AUTO_INCREMENT PRIMARY KEY,
    nimi        VARCHAR(100) NOT NULL,
    mahtuvus_min INT NOT NULL,
    mahtuvus_max INT NOT NULL,
    varustus    TEXT,
    markus      TEXT,
    CONSTRAINT chk_mahtuvus CHECK (mahtuvus_min <= mahtuvus_max)
);

-- ------------------------------------------------------------
-- Tabel: kasutajad
-- Kõik süsteemi kasutajad (õpilased, õpetajad, treenerid jne)
-- ------------------------------------------------------------
CREATE TABLE kasutajad (
    kasutaja_id  INT AUTO_INCREMENT PRIMARY KEY,
    eesnimi      VARCHAR(100) NOT NULL,
    perenimi     VARCHAR(100) NOT NULL,
    email        VARCHAR(150) NOT NULL UNIQUE,
    parool_hash  VARCHAR(255) NOT NULL,
    roll         ENUM('Õpetaja','Treener','Administraator','Külaline','Õpilane') NOT NULL DEFAULT 'Õpilane',
    loodud       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    aktiivne     BOOLEAN NOT NULL DEFAULT TRUE
);

-- ------------------------------------------------------------
-- Tabel: spordiala
-- Pakutavad spordialad / trennid
-- ------------------------------------------------------------
CREATE TABLE spordiala (
    spordiala_id    INT AUTO_INCREMENT PRIMARY KEY,
    nimi            VARCHAR(100) NOT NULL,
    kirjeldus       TEXT,
    ruum_id         INT NOT NULL,
    trenni_aeg_algus TIME NOT NULL,
    trenni_aeg_lopp  TIME NOT NULL,
    mis_paevad      VARCHAR(50) NOT NULL,   -- nt 'E-N', 'E,K,R'
    kordade_arv_naadalas INT NOT NULL DEFAULT 4,
    max_osalejad    INT NOT NULL,
    treener_id      INT,                    -- NULL = isetehtud treeningkava (jõusaal)
    CONSTRAINT fk_spordiala_ruum    FOREIGN KEY (ruum_id)    REFERENCES ruumid(ruum_id),
    CONSTRAINT fk_spordiala_treener FOREIGN KEY (treener_id) REFERENCES kasutajad(kasutaja_id)
);

-- ------------------------------------------------------------
-- Tabel: broneeringud
-- Kasutaja broneering konkreetsele spordialale / trennile
-- ------------------------------------------------------------
CREATE TABLE broneeringud (
    broneering_id   INT AUTO_INCREMENT PRIMARY KEY,
    kasutaja_id     INT NOT NULL,
    spordiala_id    INT NOT NULL,
    broneeritud     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    staatus         ENUM('Aktiivne','Tühistatud','Lõppenud') NOT NULL DEFAULT 'Aktiivne',
    CONSTRAINT fk_broneering_kasutaja  FOREIGN KEY (kasutaja_id)  REFERENCES kasutajad(kasutaja_id),
    CONSTRAINT fk_broneering_spordiala FOREIGN KEY (spordiala_id) REFERENCES spordiala(spordiala_id),
    CONSTRAINT uq_kasutaja_spordiala   UNIQUE (kasutaja_id, spordiala_id)   -- üks broneering per spordiala
);

-- ------------------------------------------------------------
-- Tabel: osalejad
-- Konkreetse treeningu registreeritud osalejad (kinnitatud)
-- ------------------------------------------------------------
CREATE TABLE osalejad (
    osaleja_id      INT AUTO_INCREMENT PRIMARY KEY,
    kasutaja_id     INT NOT NULL,
    spordiala_id    INT NOT NULL,
    liitumise_kuupäev DATE NOT NULL DEFAULT (CURRENT_DATE),
    CONSTRAINT fk_osaleja_kasutaja  FOREIGN KEY (kasutaja_id)  REFERENCES kasutajad(kasutaja_id),
    CONSTRAINT fk_osaleja_spordiala FOREIGN KEY (spordiala_id) REFERENCES spordiala(spordiala_id),
    CONSTRAINT uq_osaleja           UNIQUE (kasutaja_id, spordiala_id)
);
