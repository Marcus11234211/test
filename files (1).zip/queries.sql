-- ============================================================
-- Sportbase andmebaas - SELECT päringud
-- Autor: Marcus Krutto
-- ============================================================

USE sportbase;

-- ------------------------------------------------------------
-- Päring 1: Kõik aktiivsed spordialad koos ruumi ja treeneri nimega
-- JOIN: spordiala -> ruumid, spordiala -> kasutajad (treener)
-- ------------------------------------------------------------
SELECT
    s.spordiala_id,
    s.nimi                                  AS spordiala,
    r.nimi                                  AS ruum,
    TIME_FORMAT(s.trenni_aeg_algus, '%H:%i') AS algus,
    TIME_FORMAT(s.trenni_aeg_lopp,  '%H:%i') AS lopp,
    s.mis_paevad,
    s.max_osalejad,
    COALESCE(CONCAT(k.eesnimi, ' ', k.perenimi), 'Isetehtud treeningkava') AS treener
FROM spordiala s
JOIN ruumid r ON s.ruum_id = r.ruum_id
LEFT JOIN kasutajad k ON s.treener_id = k.kasutaja_id
ORDER BY r.nimi, s.trenni_aeg_algus;

-- ------------------------------------------------------------
-- Päring 2: Mitu osalejat on igal spordialaL? (GROUP BY)
-- Näitab ka max osalejate arvu ja täitumise protsenti
-- ------------------------------------------------------------
SELECT
    s.nimi                              AS spordiala,
    s.max_osalejad,
    COUNT(o.osaleja_id)                 AS praegused_osalejad,
    ROUND(COUNT(o.osaleja_id) * 100.0 / s.max_osalejad, 1) AS taituvus_protsent
FROM spordiala s
LEFT JOIN osalejad o ON s.spordiala_id = o.spordiala_id
GROUP BY s.spordiala_id, s.nimi, s.max_osalejad
ORDER BY taituvus_protsent DESC;

-- ------------------------------------------------------------
-- Päring 3: Õpilaste broneeringud koos spordiala infoga (WHERE + JOIN)
-- Näitab ainult aktiivseid broneeringuid
-- ------------------------------------------------------------
SELECT
    CONCAT(k.eesnimi, ' ', k.perenimi)  AS kasutaja,
    k.roll,
    s.nimi                              AS spordiala,
    r.nimi                              AS ruum,
    b.broneeritud,
    b.staatus
FROM broneeringud b
JOIN kasutajad k  ON b.kasutaja_id  = k.kasutaja_id
JOIN spordiala s  ON b.spordiala_id = s.spordiala_id
JOIN ruumid r     ON s.ruum_id      = r.ruum_id
WHERE b.staatus = 'Aktiivne'
ORDER BY k.perenimi, s.nimi;

-- ------------------------------------------------------------
-- Päring 4: Kasutajad, kes pole ühelegi spordialale registreerunud
-- (LEFT JOIN + WHERE NULL — leiab "tühjad" kasutajad)
-- ------------------------------------------------------------
SELECT
    k.kasutaja_id,
    CONCAT(k.eesnimi, ' ', k.perenimi)  AS kasutaja,
    k.roll,
    k.email
FROM kasutajad k
LEFT JOIN osalejad o ON k.kasutaja_id = o.kasutaja_id
WHERE o.osaleja_id IS NULL
  AND k.roll NOT IN ('Administraator', 'Külaline')
ORDER BY k.roll, k.perenimi;

-- ------------------------------------------------------------
-- Päring 5: Iga kasutaja broneeringute arv rollide kaupa (GROUP BY + HAVING)
-- Näitab ainult neid rolle, kus on vähemalt 1 broneering
-- ------------------------------------------------------------
SELECT
    k.roll,
    COUNT(DISTINCT b.kasutaja_id)   AS kasutajate_arv,
    COUNT(b.broneering_id)          AS broneeringuid_kokku,
    SUM(b.staatus = 'Aktiivne')     AS aktiivseid,
    SUM(b.staatus = 'Tühistatud')   AS tyhistatud,
    SUM(b.staatus = 'Lõppenud')     AS loppenud
FROM kasutajad k
LEFT JOIN broneeringud b ON k.kasutaja_id = b.kasutaja_id
GROUP BY k.roll
HAVING COUNT(b.broneering_id) > 0
ORDER BY broneeringuid_kokku DESC;

-- ------------------------------------------------------------
-- Päring 6 (BOONUS): Spordihalli graafikuvaade — kes on millal kohal
-- Osalejad spordihallis koos liitumise kuupäevaga
-- ------------------------------------------------------------
SELECT
    r.nimi                              AS ruum,
    s.nimi                              AS spordiala,
    CONCAT(k.eesnimi, ' ', k.perenimi) AS osaleja,
    o.liitumise_kuupäev
FROM osalejad o
JOIN kasutajad k ON o.kasutaja_id  = k.kasutaja_id
JOIN spordiala s ON o.spordiala_id = s.spordiala_id
JOIN ruumid    r ON s.ruum_id      = r.ruum_id
WHERE r.nimi = 'Spordihall'
ORDER BY s.nimi, k.perenimi;

-- ------------------------------------------------------------
-- TESTIMINE: Proovi sisestada osaleja olematu spordiala ID-ga
-- See peaks andma FOREIGN KEY vea!
-- ------------------------------------------------------------
-- INSERT INTO osalejad (kasutaja_id, spordiala_id, liitumise_kuupäev)
-- VALUES (5, 999, CURRENT_DATE);
-- Tulemus: ERROR 1452 (23000): Cannot add or update a child row:
--   a foreign key constraint fails (`sportbase`.`osalejad`,
--   CONSTRAINT `fk_osaleja_spordiala` FOREIGN KEY (`spordiala_id`)
--   REFERENCES `spordiala` (`spordiala_id`))
