-- ============================================================
-- queries.sql — Päringud andmebaasile
-- Projekt: Raamatukogu laenutussüsteem
-- Sisaldab: SELECT, WHERE, JOIN, GROUP BY, ORDER BY, HAVING
-- ============================================================

USE projekt_db;

-- ============================================================
-- PÄRING 1: Kõik raamatud koos autori ja žanri nimedega (JOIN)
-- Eesmärk: Näidata täielikku raamatute nimekirja inimloetavas kujul
-- ============================================================
SELECT
    r.raamat_id,
    r.pealkiri,
    CONCAT(a.eesnimi, ' ', a.perenimi) AS autor,
    z.nimetus                          AS zanr,
    r.aasta,
    r.eksemplare
FROM raamatud r
JOIN autorid a ON r.autor_id = a.autor_id
JOIN zanrid  z ON r.zanr_id  = z.zanr_id
ORDER BY r.aasta ASC;


-- ============================================================
-- PÄRING 2: Aktiivsed laenud koos liikme ja raamatu infoga (JOIN + WHERE)
-- Eesmärk: Näidata, millised raamatud on praegu välja laenutatud
-- ============================================================
SELECT
    l.laen_id,
    CONCAT(m.eesnimi, ' ', m.perenimi) AS liige,
    m.email,
    r.pealkiri                          AS raamat,
    l.laenu_kp,
    l.tagastus_tahtaeg,
    DATEDIFF(l.tagastus_tahtaeg, CURRENT_DATE) AS paevi_jaanud
FROM laenud l
JOIN liikmed  m ON l.liige_id  = m.liige_id
JOIN raamatud r ON l.raamat_id = r.raamat_id
WHERE l.staatus = 'aktiivne'
ORDER BY l.tagastus_tahtaeg ASC;


-- ============================================================
-- PÄRING 3: Hilinenud tagastajad (WHERE + JOIN)
-- Eesmärk: Leida liikmed, kes ei ole õigeaegselt raamatu tagastanud
-- ============================================================
SELECT
    CONCAT(m.eesnimi, ' ', m.perenimi)  AS liige,
    m.email,
    m.telefon,
    r.pealkiri                           AS raamat,
    l.tagastus_tahtaeg,
    DATEDIFF(CURRENT_DATE, l.tagastus_tahtaeg) AS hilinenud_paevi
FROM laenud l
JOIN liikmed  m ON l.liige_id  = m.liige_id
JOIN raamatud r ON l.raamat_id = r.raamat_id
WHERE l.staatus = 'hilinenud'
ORDER BY hilinenud_paevi DESC;


-- ============================================================
-- PÄRING 4: Populaarseimad raamatud — laenukordade arv (GROUP BY + JOIN)
-- Eesmärk: Statistika, milliseid raamatuid laenutatakse enim
-- ============================================================
SELECT
    r.pealkiri,
    CONCAT(a.eesnimi, ' ', a.perenimi) AS autor,
    COUNT(l.laen_id)                   AS laenatud_kokku,
    SUM(CASE WHEN l.staatus = 'tagastatud' THEN 1 ELSE 0 END) AS tagastatud,
    SUM(CASE WHEN l.staatus = 'aktiivne'   THEN 1 ELSE 0 END) AS hetkel_laenul
FROM raamatud r
JOIN autorid a ON r.autor_id = a.autor_id
LEFT JOIN laenud l ON r.raamat_id = l.raamat_id
GROUP BY r.raamat_id, r.pealkiri, autor
ORDER BY laenatud_kokku DESC;


-- ============================================================
-- PÄRING 5: Aktiivsed liikmed, kellel on üle 1 laenu (GROUP BY + HAVING)
-- Eesmärk: Leida enim laenanud liikmed filtreeritult
-- ============================================================
SELECT
    CONCAT(m.eesnimi, ' ', m.perenimi) AS liige,
    m.email,
    COUNT(l.laen_id)                   AS laene_kokku,
    MIN(l.laenu_kp)                    AS esimene_laen,
    MAX(l.laenu_kp)                    AS viimane_laen
FROM liikmed m
JOIN laenud l ON m.liige_id = l.liige_id
WHERE m.aktiivne = 1
GROUP BY m.liige_id, m.eesnimi, m.perenimi, m.email
HAVING COUNT(l.laen_id) > 1
ORDER BY laene_kokku DESC;


-- ============================================================
-- PÄRING 6: Žanrite populaarsus (GROUP BY + JOIN)
-- Eesmärk: Milliseid žanre laenutatakse enim
-- ============================================================
SELECT
    z.nimetus              AS zanr,
    COUNT(DISTINCT r.raamat_id) AS raamatuid,
    COUNT(l.laen_id)            AS laenukordade_arv
FROM zanrid z
LEFT JOIN raamatud r ON z.zanr_id = r.zanr_id
LEFT JOIN laenud   l ON r.raamat_id = l.raamat_id
GROUP BY z.zanr_id, z.nimetus
ORDER BY laenukordade_arv DESC;


-- ============================================================
-- PÄRING 7: Konkreetse autori raamatud ja nende laenude ajalugu
-- (mitme-tasandiline JOIN + WHERE filter)
-- ============================================================
SELECT
    CONCAT(a.eesnimi, ' ', a.perenimi) AS autor,
    r.pealkiri,
    r.aasta,
    l.laenu_kp,
    l.tagastus_tahtaeg,
    l.staatus,
    CONCAT(m.eesnimi, ' ', m.perenimi) AS laenanud_liige
FROM autorid a
JOIN raamatud r ON a.autor_id = r.autor_id
LEFT JOIN laenud  l ON r.raamat_id = l.raamat_id
LEFT JOIN liikmed m ON l.liige_id  = m.liige_id
WHERE a.rahvus = 'Eesti'
ORDER BY a.perenimi, r.pealkiri, l.laenu_kp;
