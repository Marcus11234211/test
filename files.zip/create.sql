-- ============================================================
-- create.sql — Tabelite loomine
-- Projekt: Raamatukogu laenutussüsteem
-- Andmebaas: projekt_db
-- ============================================================

-- Kasuta õiget andmebaasi
USE projekt_db;

-- ------------------------------------------------------------
-- Tabel: autorid
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS autorid (
    autor_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    eesnimi     VARCHAR(100) NOT NULL,
    perenimi    VARCHAR(100) NOT NULL,
    synniaasta  YEAR,
    rahvus      VARCHAR(60),
    loodud      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabel: zanrid
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS zanrid (
    zanr_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nimetus     VARCHAR(80) NOT NULL UNIQUE,
    kirjeldus   TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabel: raamatud
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS raamatud (
    raamat_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pealkiri    VARCHAR(255) NOT NULL,
    autor_id    INT UNSIGNED NOT NULL,
    zanr_id     INT UNSIGNED NOT NULL,
    isbn        VARCHAR(20) UNIQUE,
    aasta       YEAR,
    lehekulgi   SMALLINT UNSIGNED,
    eksemplare  TINYINT UNSIGNED NOT NULL DEFAULT 1,
    loodud      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_raamat_autor FOREIGN KEY (autor_id) REFERENCES autorid(autor_id) ON DELETE RESTRICT,
    CONSTRAINT fk_raamat_zanr  FOREIGN KEY (zanr_id)  REFERENCES zanrid(zanr_id)   ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabel: liikmed
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS liikmed (
    liige_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    eesnimi     VARCHAR(100) NOT NULL,
    perenimi    VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    telefon     VARCHAR(20),
    registr_kp  DATE NOT NULL DEFAULT (CURRENT_DATE),
    aktiivne    TINYINT(1) NOT NULL DEFAULT 1,
    loodud      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabel: laenud
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS laenud (
    laen_id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    liige_id        INT UNSIGNED NOT NULL,
    raamat_id       INT UNSIGNED NOT NULL,
    laenu_kp        DATE NOT NULL DEFAULT (CURRENT_DATE),
    tagastus_tahtaeg DATE NOT NULL,
    tagastatud_kp   DATE,
    staatus         ENUM('aktiivne','tagastatud','hilinenud') NOT NULL DEFAULT 'aktiivne',
    loodud          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_laen_liige  FOREIGN KEY (liige_id)  REFERENCES liikmed(liige_id)  ON DELETE RESTRICT,
    CONSTRAINT fk_laen_raamat FOREIGN KEY (raamat_id) REFERENCES raamatud(raamat_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Indeksid jõudluse parandamiseks
-- ------------------------------------------------------------
CREATE INDEX idx_laenud_liige   ON laenud(liige_id);
CREATE INDEX idx_laenud_raamat  ON laenud(raamat_id);
CREATE INDEX idx_laenud_staatus ON laenud(staatus);
CREATE INDEX idx_raamatud_autor ON raamatud(autor_id);
