-- ============================================================
-- insert.sql — Testandmed
-- Projekt: Raamatukogu laenutussüsteem
-- Kokku: 5 autorit, 5 žanrit, 8 raamatut, 5 liiget, 10 laenu
--        = 33 kirjet kokku (üle 20 nõutu)
-- ============================================================

USE projekt_db;

-- ------------------------------------------------------------
-- Autorid (5 kirjet)
-- ------------------------------------------------------------
INSERT INTO autorid (eesnimi, perenimi, synniaasta, rahvus) VALUES
    ('Anton Hansen', 'Tammsaare',  1878, 'Eesti'),
    ('Jaan',         'Kross',      1920, 'Eesti'),
    ('Andrei',       'Ivanov',     1971, 'Eesti'),
    ('George',       'Orwell',     1903, 'Briti'),
    ('Gabriel',      'García Márquez', 1927, 'Colombia');

-- ------------------------------------------------------------
-- Žanrid (5 kirjet)
-- ------------------------------------------------------------
INSERT INTO zanrid (nimetus, kirjeldus) VALUES
    ('Romaan',        'Pikemahulise proosa vorm, mis kujutab fiktiivseid sündmusi'),
    ('Ajalooline',    'Tegevus toimub minevikus, põhineb ajaloolistel sündmustel'),
    ('Ulme',          'Teaduslik-fantastiline või spekulatiivne ilukirjandus'),
    ('Realism',       'Elu kujutatakse tegelikkusele vastavalt, ilma idealiseerimata'),
    ('Maagiline realism', 'Argiellu on põimitud maagilisi elemente');

-- ------------------------------------------------------------
-- Raamatud (8 kirjet)
-- ------------------------------------------------------------
INSERT INTO raamatud (pealkiri, autor_id, zanr_id, isbn, aasta, lehekulgi, eksemplare) VALUES
    ('Tõde ja õigus I',         1, 4, '978-9985-65-234-1', 1926, 412, 3),
    ('Tõde ja õigus II',        1, 4, '978-9985-65-235-8', 1929, 386, 2),
    ('Keisri hull',             2, 2, '978-9985-65-010-1', 1978, 280, 2),
    ('Paigallend',              2, 1, '978-9985-65-011-8', 1998, 340, 1),
    ('Hanumani teekond Lollandile', 3, 1, '978-9985-65-500-7', 2001, 228, 2),
    ('Nineteen Eighty-Four',    4, 3, '978-0-14-103614-4', 1949, 328, 3),
    ('Animal Farm',             4, 3, '978-0-14-303943-3', 1945, 112, 4),
    ('Sada aastat üksindust',   5, 5, '978-9985-65-600-4', 1967, 448, 2);

-- ------------------------------------------------------------
-- Liikmed (5 kirjet)
-- ------------------------------------------------------------
INSERT INTO liikmed (eesnimi, perenimi, email, telefon, registr_kp) VALUES
    ('Mari',    'Tamm',     'mari.tamm@email.ee',    '+372 5123 4567', '2023-01-15'),
    ('Jüri',    'Sepp',     'jyri.sepp@email.ee',    '+372 5234 5678', '2023-03-22'),
    ('Liina',   'Kask',     'liina.kask@email.ee',   '+372 5345 6789', '2023-06-01'),
    ('Peeter',  'Mets',     'peeter.mets@email.ee',  '+372 5456 7890', '2024-01-10'),
    ('Kadri',   'Oja',      'kadri.oja@email.ee',    '+372 5567 8901', '2024-04-05');

-- ------------------------------------------------------------
-- Laenud (10 kirjet)
-- ------------------------------------------------------------
INSERT INTO laenud (liige_id, raamat_id, laenu_kp, tagastus_tahtaeg, tagastatud_kp, staatus) VALUES
    -- Tagastatud laenud
    (1, 1, '2024-09-01', '2024-09-22', '2024-09-20', 'tagastatud'),
    (1, 6, '2024-10-05', '2024-10-26', '2024-10-25', 'tagastatud'),
    (2, 3, '2024-10-10', '2024-10-31', '2024-10-30', 'tagastatud'),
    (3, 7, '2024-11-01', '2024-11-22', '2024-11-21', 'tagastatud'),
    (4, 2, '2024-11-15', '2024-12-06', '2024-12-05', 'tagastatud'),
    -- Aktiivsed laenud
    (1, 8, '2025-03-01', '2025-03-22', NULL,          'aktiivne'),
    (2, 5, '2025-03-10', '2025-03-31', NULL,          'aktiivne'),
    (3, 4, '2025-03-15', '2025-04-05', NULL,          'aktiivne'),
    -- Hilinenud laenud
    (4, 6, '2025-01-10', '2025-01-31', NULL,          'hilinenud'),
    (5, 1, '2025-01-20', '2025-02-10', NULL,          'hilinenud');
