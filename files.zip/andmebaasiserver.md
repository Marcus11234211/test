# Andmebaasiserver — projekt-andmebaas-IT24-sinunimi

## Valitud tarkvara: MariaDB

### Versioon
```
mariadb  Ver 15.1 Distrib 10.11.x-MariaDB, for debian-linux-gnu (x86_64)
```

### Miks MariaDB?

MariaDB valiti MySQL asemel järgmistel põhjustel:
- **Avatud lähtekood** — täielikult kogukonna hallatud, ilma Oracle piiranguteta
- **MySQL ühilduvus** — kõik MySQL käsud ja tööriistad toimivad muutmata kujul
- **Ubuntu vaikimisi** — Ubuntu repositooriumides on MariaDB soovitatav valik
- **Jõudlus** — mitmed optimeeringud võrreldes MySQL-iga
- **Turvalisus** — aktiivsed turvauuendused

---

## Paigaldus ja seadistamine

### 1. Paigaldus

```bash
sudo apt update
sudo apt install -y mariadb-server mariadb-client
```

### 2. Teenuse käivitamine

```bash
sudo systemctl enable mariadb
sudo systemctl start mariadb
sudo systemctl status mariadb
```

### 3. Turvaline seadistamine (`mysql_secure_installation`)

```bash
sudo mysql_secure_installation
```

**Läbitud sammud:**
| Küsimus | Vastus |
|---|---|
| Enter current password for root | (tühi — Enter) |
| Switch to unix_socket authentication? | Y |
| Change the root password? | Y → tugev parool seatud |
| Remove anonymous users? | **Y** |
| Disallow root login remotely? | **Y** |
| Remove test database and access to it? | **Y** |
| Reload privilege tables now? | **Y** |

### 4. Eraldi MySQL kasutaja loomine

```sql
-- Logi sisse root'ina
sudo mysql -u root -p

-- Loo andmebaas
CREATE DATABASE IF NOT EXISTS projekt_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Loo kasutaja (asenda 'TugevParool123!' oma parooliga)
CREATE USER 'projekt_user'@'localhost' IDENTIFIED BY 'TugevParool123!';

-- Anna õigused ainult projekt_db andmebaasile
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER
    ON projekt_db.*
    TO 'projekt_user'@'localhost';

-- Rakenda muudatused
FLUSH PRIVILEGES;

-- Kontrolli
SHOW GRANTS FOR 'projekt_user'@'localhost';
```

#### Kasutaja andmed ja õigused

| Väli | Väärtus |
|---|---|
| **Kasutajanimi** | `projekt_user` |
| **Host** | `localhost` |
| **Andmebaas** | `projekt_db` |
| **Õigused** | SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER |
| **Root kaugjuurdepääs** | Keelatud |
| **Anonüümsed kasutajad** | Eemaldatud |

> ⚠️ Root kasutajat rakenduses **ei kasutata**. Kõik rakenduse päringud käivad läbi `projekt_user`.

### 5. Andmebaasi initialiseerimine

```bash
# Käivita SQL-failid järjekorras
sudo mysql -u projekt_user -p projekt_db < sql/create.sql
sudo mysql -u projekt_user -p projekt_db < sql/insert.sql

# Kontrolli
sudo mysql -u projekt_user -p projekt_db -e "SHOW TABLES;"
```

### 6. Teenuse kontroll

```bash
sudo systemctl is-enabled mariadb   # enabled
sudo systemctl is-active mariadb    # active
sudo ss -tlnp | grep ':3306'        # port 3306 kuulab localhost'il
```
