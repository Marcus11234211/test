# Veebiserver — projekt-veeb-IT24-sinunimi

## Valitud tarkvara: Nginx

### Versioon
```
nginx version: nginx/1.24.0 (Ubuntu)
```

### Miks Nginx?

| Kriteerium | Apache | Nginx | Caddy |
|---|---|---|---|
| Jõudlus staatilisel sidul | Hea | **Väga hea** | Hea |
| Mälukasutus | Kõrge | **Madal** | Madal |
| HTTPS seadistamine | Käsitsi | Käsitsi | **Automaatne** |
| Dokumentatsioon & tugi | Suur | **Suur** | Kasvav |
| Õppelabori sobivus | Jah | **Jah** | Jah |

**Põhjus:** Nginx valiti, kuna see on ressursisäästlik, sobib hästi Linux-serveritele, on laialt kasutatav tootmiskeskkonnas ning pakub head jõudlust ka väiksema koormusega serveritel. Nginx-il on selge konfiguratsioonisüntaks ja lai kogukonnatugi.

---

## Paigaldus ja seadistamine

### 1. Paigaldus

```bash
sudo apt update
sudo apt install -y nginx
```

### 2. HTTPS sertifikaadi loomine (self-signed õppelaboris)

```bash
sudo mkdir -p /etc/nginx/ssl

sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/nginx/ssl/server.key \
  -out /etc/nginx/ssl/server.crt \
  -subj "/C=EE/ST=Harjumaa/L=Tallinn/O=IT24/CN=projekt-veeb-IT24-sinunimi"
```

### 3. Nginx virtuaalhost konfiguratsioon

Fail: `/etc/nginx/sites-available/projekt`

```nginx
server {
    listen 80;
    server_name projekt-veeb-IT24-sinunimi;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name projekt-veeb-IT24-sinunimi;

    ssl_certificate     /etc/nginx/ssl/server.crt;
    ssl_certificate_key /etc/nginx/ssl/server.key;

    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;

    root /var/www/projekt;
    index index.html index.htm;

    location / {
        try_files $uri $uri/ =404;
    }

    access_log /var/log/nginx/projekt_access.log;
    error_log  /var/log/nginx/projekt_error.log;
}
```

### 4. Aktiveerime konfiguratsiooni

```bash
sudo ln -s /etc/nginx/sites-available/projekt /etc/nginx/sites-enabled/
sudo mkdir -p /var/www/projekt
echo "<h1>projekt-veeb-IT24-sinunimi töötab!</h1>" | sudo tee /var/www/projekt/index.html

sudo nginx -t          # kontrolli konfiguratsiooni
sudo systemctl reload nginx
```

### 5. Teenuse haldus

```bash
# Käivita ja luba autostart
sudo systemctl enable nginx
sudo systemctl start nginx

# Kontrolli staatust
sudo systemctl status nginx
```

**Oodatav väljund:**
```
● nginx.service - A high performance web server and a reverse proxy server
     Loaded: loaded (/lib/systemd/system/nginx.service; enabled; vendor preset: enabled)
     Active: active (running) since ...
```

### 6. Test klientmasinast

```bash
# HTTP → HTTPS redirect test
curl -I http://projekt-veeb-IT24-sinunimi

# HTTPS test (self-signed sert → -k lipp)
curl -k https://projekt-veeb-IT24-sinunimi

# Brauserist: https://projekt-veeb-IT24-sinunimi
# (aktsepteeri self-signed hoiatus)
```

---

## Tulemuste kontroll

```bash
sudo systemctl is-enabled nginx   # peaks näitama: enabled
sudo systemctl is-active nginx    # peaks näitama: active
sudo ss -tlnp | grep ':443'       # port 443 kuulab
```
